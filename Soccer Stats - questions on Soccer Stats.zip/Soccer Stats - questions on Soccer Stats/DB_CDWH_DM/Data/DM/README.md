In case of straightforward reproduction, one can simply import these csv files after creating the DM database and tables without having to 
execute the DM creation scripts.