In case of straightforward reproduction, one can simply import these csv files after creating the CDWH database and tables without having to 
execute the CDWH creation scripts.