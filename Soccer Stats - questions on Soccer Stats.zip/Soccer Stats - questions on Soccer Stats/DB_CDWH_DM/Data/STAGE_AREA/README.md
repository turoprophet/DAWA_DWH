The following csv files should be imported into a MySQL database to be used as a staging area for our Data Warehouse.
PHPMyAdmin allows to import csv compressed files (csv.zip).

Data sources: 
->Football statistics: http://www.football-data.co.uk/
->Information on Stadiums and their respective teams (stadiums.csv) compiled by us ad-ho

It is advised to name your database "dawa_stage" since all posterior scripts that refer to this database use this name.

Note that the csv.zip files contained in this folder have already been stripped of all unrelevant information.